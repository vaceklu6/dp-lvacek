from django import forms
from django.core.exceptions import ValidationError
from .models import Anycast, Users
from .tools import bigger_equal_zero, bigger_than_zero, empty_string, valid_ipv4_address, valid_ipv6_address, setup_ip, duplicity_users_name

STACK_CHOICES= [
    (True, True), (False, False)
    ]

class LocationForm(forms.Form):
    name = forms.CharField(max_length=40, required = True)
    stack = forms.ChoiceField(choices=STACK_CHOICES, widget=forms.RadioSelect())
    domain_name = forms.CharField(max_length=260, required = True)

class ProbeForm(forms.Form):
    name = forms.CharField(max_length=40)
    ipv4_address = forms.GenericIPAddressField(required = False, validators=[valid_ipv4_address])
    ipv6_address = forms.GenericIPAddressField(required = False, validators=[valid_ipv6_address])
    def clean(self):
        setup_ip(self.cleaned_data)
        return self.cleaned_data

class AnycastForm(forms.Form):
    name = forms.CharField(max_length=40, required = False)
    letter= forms.CharField(max_length=3, required = True)
    ipv4_address = forms.GenericIPAddressField(required = False, validators=[valid_ipv4_address])
    ipv6_address = forms.GenericIPAddressField(required = False, validators=[valid_ipv6_address])
    notes = forms.CharField(max_length=200, required = False)

    def clean(self):
        setup_ip(self.cleaned_data)
        return self.cleaned_data

class AnycastToLocationForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(AnycastToLocationForm, self).__init__(*args, **kwargs)
        self.fields['anycast'] = forms.MultipleChoiceField(
            choices=[(o.id, o.id) for o in Anycast.objects.all().order_by('letter','name')]
        )

class SelectUserForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(SelectUserForm, self).__init__(*args, **kwargs)
        self.fields['user'] = forms.MultipleChoiceField(
            choices=[(o.id, o.id) for o in Users.objects.all().order_by('name')]
        )

##  Create user with password form with password checks
class UserForm(forms.Form):
    name = forms.CharField(max_length=40, required = True, validators=[duplicity_users_name])
    password = forms.CharField(widget=forms.PasswordInput, required = True, validators=[empty_string])
    confirm_password = forms.CharField(widget=forms.PasswordInput, required = True, validators=[empty_string])

    def clean(self):
        try:
            field1 = self.cleaned_data['password']
        except:
            self.add_error("password", "is empty or contains only spaces.")
            return self.cleaned_data

        try:
            field2 = self.cleaned_data['confirm_password']
        except:
            self.add_error("confirm_password", "is empty or contains only spaces.")
            return self.cleaned_data

        if field1 != field2:
            self.add_error("password", "Password and Confirm Password missmatch.")

        return self.cleaned_data

class NameUserForm(forms.Form):
    name = forms.CharField(max_length=40, required = True)

## Change password form with password checks
class PasswordUserForm(forms.Form):
    password = forms.CharField(widget=forms.PasswordInput, required = True, validators=[empty_string])
    confirm_password = forms.CharField(widget=forms.PasswordInput, required = True, validators=[empty_string])
    old_password = forms.CharField(widget=forms.PasswordInput, required = True, validators=[empty_string])

    def __init__(self, *args, **kwargs):
        self.user_id = kwargs.pop('extra')
        super(PasswordUserForm, self).__init__(*args, **kwargs)


    def clean(self):
        try:
            field1 = self.cleaned_data['old_password']
        except:
            self.add_error("old_password", "is empty or contains only spaces.")
            return self.cleaned_data

        try:
            field2 = self.cleaned_data['password']
        except:
            self.add_error("password", "is empty or contains only spaces.")
            return self.cleaned_data

        try:
            field3 = self.cleaned_data['confirm_password']
        except:
            self.add_error("confirm_password", "is empty or contains only spaces.")
            return self.cleaned_data

        old_db_pass = Users.objects.get(id = self.user_id).password
        if field1 != old_db_pass:
            self.add_error("old_password", "Wrong password")
            return self.cleaned_data

        if field2 != field3:
            self.add_error("password", "Password and Confirm Password missmatch.")

        return self.cleaned_data

class CollectorFrequencyForm(forms.Form):
    frequency = forms.IntegerField(required = True, validators=[bigger_than_zero])

class ElasticServerForm(forms.Form):
    elastic_server = forms.CharField(max_length=260, required = True)
    elastic_index = forms.CharField(max_length=260, required = True)
    elastic_port = forms.IntegerField(validators=[bigger_than_zero])

class RequestsForm(forms.Form):
    timeout_standalone = forms.IntegerField(validators=[bigger_than_zero])
    timeout_stack = forms.IntegerField(validators=[bigger_than_zero])
    retry = forms.IntegerField(validators=[bigger_equal_zero])

