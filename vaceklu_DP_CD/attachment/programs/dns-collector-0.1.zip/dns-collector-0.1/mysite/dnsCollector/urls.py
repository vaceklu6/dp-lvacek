from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('config', views.index_config, name='index_config'),
#    path('configPush', views.index_config_push, name='index_config_push'),
    path('probes/', views.probes, name= 'probes'),

    ## Location
    path('location/', views.location, name= 'location'),
    path('<int:location_id>/', views.location_detail, name= 'location_detail'),
    path('modify_location/<int:location_id>', views.modify_location, name= 'modify_location'),
    path('delete_location/<int:location_id>', views.delete_location, name= 'delete_location'),
    path('location_add_anycast/<int:location_id>', views.location_add_anycast, name= 'location_add_anycast'),
    path('location_select_user/<int:location_id>', views.location_select_user, name= 'location_select_user'),
    path('location_remove_user/<int:location_id>', views.location_remove_user, name= 'location_remove_user'),
    path('location_delete_anycast/<int:location_id>/<int:anycast_id>', views.location_delete_anycast, name= 'location_delete_anycast'),

    ## Probe at location
    path('<int:location_id>/probes/<int:probe_id>/', views.probe_detail, name= 'probe_detail'),
    path('<int:location_id>/modify_probe/<int:probe_id>/', views.modify_probe, name= 'modify_probe'),
    path('<int:location_id>/delete_probe/<int:probe_id>/', views.delete_probe, name= 'delete_probe'),

    ## Anycast
    path('anycast/', views.anycast, name= 'anycast'),
    path('anycast_detail/<int:anycast_id>/', views.anycast_detail, name= 'anycast_detail'),
    path('modify_anycast/<int:anycast_id>',  views.modify_anycast, name= 'modify_anycast'),
    path('delete_anycast/<int:anycast_id>',  views.delete_anycast, name= 'delete_anycast'),
    path('anycast_delete_location/<int:anycast_id>/<int:location_id>', views.anycast_delete_location, name= 'anycast_delete_location'),

    ## Collector
    path('collector/', views.collector, name= 'collector'),
    path('collector_frequency/', views.collector_frequency, name= 'collector_frequency'),
    path('collector_requests/', views.collector_requests, name= 'collector_requests'),
#    path('collector_restart/', views.collector_restart, name= 'collector_restart'),

    ## Elastic server
    path('elastic_server/', views.elastic_server, name= 'elastic_server'),
    path('remove_elastic_user/', views.remove_elastic_user, name= 'remove_elastic_user'),

    ## Elastic User
#    path('elastic_user/', views.elastic_user, name= 'elastic_user'),
#    path('name_elastic_user/<int:user_id>', views.name_elastic_user, name= 'name_elastic_user'),
#    path('password_elastic_user/<int:user_id>', views.password_elastic_user, name= 'password_elastic_user'),
#    path('delete_elastic_user/<int:user_id>', views.delete_elastic_user, name= 'delete_elastic_user'),

    path('users/', views.users, name= 'users'),
    path('name_user/<int:user_id>', views.name_user, name= 'name_user'),
    path('password_user/<int:user_id>', views.password_user, name= 'password_user'),
    path('delete_user/<int:user_id>', views.delete_user, name= 'delete_user'),
]

