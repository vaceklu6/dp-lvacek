from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from django.apps import apps
import requests
import json
import logging

from ..models import ItemsDB, Users
from ..tools import verify_password, hash_password, render_debug, CollectorAPI, render_error
from ..forms import CollectorFrequencyForm, ElasticServerForm, SelectUserForm, RequestsForm


def renderCollectorSite(request, form={}):
    all_users = [(o.name, o.id) for o in Users.objects.all()]
    user_id = ItemsDB.objects.filter(key = 'elastic_user_id')[0]
    user = None
    if user_id.value != "":
        user = Users.objects.get(id = int(user_id.value)).name

    app_config = apps.get_app_config('dnsCollector')
    collector_frequency = ItemsDB.objects.filter( key = 'frequency')[0].value

    handler_text = "Start"
    if app_config.c.get_process_lock() == 1:
        handler_text = "Stop"

    app_config.c.set_asn_database_file()
    asn_database = app_config.c.get_asn_database_status()[1]

    elastic_server = ItemsDB.objects.filter(key='elastic_server')[0]
    elastic_port = ItemsDB.objects.filter(key='elastic_port')[0]
    elastic_index = ItemsDB.objects.filter(key='elastic_index')[0]
    context = {
        'collector_frequency': collector_frequency,
        'handler_text' : handler_text,
        'elastic_server': elastic_server,
        'elastic_port': elastic_port,
        'elastic_index': elastic_index,
        'asn_database': asn_database,
        'user': user,
        'all_users' : all_users,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    template = loader.get_template('static/collector.html')
    return HttpResponse(template.render(context,request))

def render_collector_frequency_site(request, form = {}):
    collector_frequency = ItemsDB.objects.filter( key = 'frequency')[0].value
    context = {
        'collector_frequency': collector_frequency,
        }
    if 'form' in form.keys():
        context['form'] = form['form']

    template = loader.get_template('static/collector_frequency.html')
    return HttpResponse(template.render(context,request))


def collector_frequency(request):
    if request.method == 'GET':
        return render_collector_frequency_site(request)
    elif request.method == 'POST':
        frequency_form = CollectorFrequencyForm(request.POST)
        if frequency_form.is_valid():
            frequency = frequency_form.cleaned_data['frequency']
            frequencyDB = ItemsDB.objects.filter(key = 'frequency')[0]
            frequencyDB.value = frequency
            frequencyDB.save()
        else:
            return render_collector_frequency_site(request, {'form': frequency_form})
        return redirect('collector')

def render_collector_requests_site(request, form = {}):
#    collector_ = ItemsDB.objects.filter( key = 'frequency')[0].value
    timeout_stack = ItemsDB.objects.filter( key = 'timeout_stack')[0].value
    timeout_standalone = ItemsDB.objects.filter( key = 'timeout_standalone')[0].value
    retry = ItemsDB.objects.filter( key = 'retry')[0].value
    context = {
        'timeout_stack': timeout_stack,
        'timeout_standalone': timeout_standalone,
        'retry': retry,
        }
    if 'form' in form.keys():
        context['form'] = form['form']

    template = loader.get_template('static/collector_requests.html')
    return HttpResponse(template.render(context,request))


def collector_requests(request):
    if request.method == 'GET':
        return render_collector_requests_site(request)
    elif request.method == 'POST':
        requests_form = RequestsForm(request.POST)
        if requests_form.is_valid():
            timeout_stack = requests_form.cleaned_data['timeout_stack']
            timeout_stackDB = ItemsDB.objects.filter(key = 'timeout_stack')[0]
            timeout_stackDB.value = timeout_stack
            timeout_stackDB.save()

            timeout_standalone = requests_form.cleaned_data['timeout_standalone']
            timeout_standaloneDB = ItemsDB.objects.filter(key = 'timeout_standalone')[0]
            timeout_standaloneDB.value = timeout_standalone
            timeout_standaloneDB.save()

            retry = requests_form.cleaned_data['retry']
            retryDB = ItemsDB.objects.filter(key = 'retry')[0]
            retryDB.value = retry
            retryDB.save()

        else:
            return render_collector_requests_site(request, {'form': requests_form})
        return redirect('collector')


def select_user(request):
    select_user_form = SelectUserForm(request.POST)
    if select_user_form.is_valid():
        selected_user = select_user_form.cleaned_data['user']
        elastic_user = ItemsDB.objects.filter(key = 'elastic_user_id')[0]
        elastic_user.value = selected_user[0]
        elastic_user.save()
    else:
        return renderCollectorSite(request, form = {'form' : select_user_form})
    return redirect('collector')

def remove_elastic_user(request):
    user_id = ItemsDB.objects.filter( key = 'elastic_user_id')[0]
    user_id.value = ""
    user_id.save()
    return redirect('collector')


def render_collector_test_site(request, responses, elastic_response):
    context = {
        'responses': responses,
        'elastic_response': elastic_response,
        }
    template = loader.get_template('static/collector_test.html')
    return HttpResponse(template.render(context,request))

## Test connection with probes and elastic
def test_collector_button(request):
    app_config = apps.get_app_config('dnsCollector')
    msg = elastic_tests()
    if msg != "":
        return render_error(request, msg)
    responses, elastic_response = app_config.c.test_collection()
    return render_collector_test_site(request, responses, elastic_response)

def elastic_tests():
    msg = ""
    if ItemsDB.objects.filter(key='elastic_server')[0].value == "":
        msg = "Elastic server is not set up."
    if ItemsDB.objects.filter(key='elastic_index')[0] == "":
        msg = "Elastic index is not set up."
    return msg

## Start/stop tread for collection data
def collector_handler(request, restart = False):
    msg = elastic_tests()
    if msg != "":
        return render_error(request, msg)

    app_config = apps.get_app_config('dnsCollector')
    frequency = int(ItemsDB.objects.filter(key = 'frequency')[0].value)

    if frequency == "":
        return render_error(request, f'Frequency is not set')
    if frequency < 1:
        return render_error(request, f'Frequency is lower than 1 second. Frequency has to be bigger or equal than 1 second.')
    app_config.c.collector_handler()
    if restart == True and app_config.c.get_process_lock() == 0:
        app_config.c.collector_handler()

    return redirect('collector')

#def collector_restart(request):
#    return collector_handler(request, restart = True)


def render_elastic_server_site(request, form = {}):
    elastic_server = ItemsDB.objects.filter(key='elastic_server')[0]
    elastic_port   = ItemsDB.objects.filter(key='elastic_port')[0]
    elastic_index  = ItemsDB.objects.filter(key='elastic_index')[0]

    context = {
        'elastic_server': elastic_server,
        'elastic_port':   elastic_port,
        'elastic_index':  elastic_index,
        }
    if 'form' in form.keys():
        context['form'] = form['form']
    template = loader.get_template('static/elastic_server.html')
    return HttpResponse(template.render(context,request))

def elastic_server(request):
    if request.method == 'GET':
        return render_elastic_server_site(request)
    elif request.method == 'POST':
        server_form = ElasticServerForm(request.POST)
        if server_form.is_valid():
            server_value = server_form.cleaned_data['elastic_server']
            port_value   = server_form.cleaned_data['elastic_port']
            index_value  = server_form.cleaned_data['elastic_index']
            elastic_server_filter = ItemsDB.objects.filter(key='elastic_server')[0]
            elastic_port_filter   = ItemsDB.objects.filter(key='elastic_port')[0]
            elastic_index_filter  = ItemsDB.objects.filter(key='elastic_index')[0]

            elastic_server = ItemsDB.objects.get(id = elastic_server_filter.id)
            elastic_port   = ItemsDB.objects.get(id = elastic_port_filter.id)
            elastic_index  = ItemsDB.objects.get(id = elastic_index_filter.id)

            elastic_server.value = server_value
            elastic_server.save()
            elastic_port.value = port_value
            elastic_port.save()
            elastic_index.value = index_value
            elastic_index.save()
        return redirect('collector')

def collector(request):
    if request.method == 'GET':
        return renderCollectorSite(request)
    elif request.method == 'POST':
        if 'user' in request.POST:
            return select_user(request)
        elif 'handler' in request.POST:
            return collector_handler(request)
        elif 'test_collect' in request.POST:
            return test_collector_button(request)
        return redirect('collector')
