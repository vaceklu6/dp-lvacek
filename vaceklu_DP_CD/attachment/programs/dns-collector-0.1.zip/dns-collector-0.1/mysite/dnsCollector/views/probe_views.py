from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
import logging

from ..models import Probe, Location
from ..forms import LocationForm, ProbeForm

# Get an instance of a logger
logger = logging.getLogger(__name__)

def render_modify_probe(request, location_id, probe_id, form={}):
    probe = Probe.objects.get(id=probe_id )
    location = Location.objects.get(id=location_id)

    template = loader.get_template('static/modify_probe.html')

    context = {
        'probe': probe,
        'location': location,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def modify_probe(request, location_id, probe_id):
    if request.method == 'GET':
        return render_modify_probe(request, location_id, probe_id)
    elif request.method == 'POST':
        probe_form = ProbeForm(request.POST)
        if probe_form.is_valid():
            probe_name = probe_form.cleaned_data['name']
            probe_ipv4 = probe_form.cleaned_data['ipv4_address']
            probe_ipv6 = probe_form.cleaned_data['ipv6_address']

            p = Probe.objects.get(id=probe_id )
            p.name         = probe_name
            p.ipv4_address = probe_ipv4
            p.ipv6_address = probe_ipv6
            p.save()
        else:
            return render_modify_probe(request, location_id, probe_id, form = {'form': probe_form})
        return redirect('probe_detail', location_id = location_id, probe_id = probe_id )

def probe_detail(request, location_id, probe_id):
    probe = Probe.objects.get(id=probe_id )
    location = Location.objects.get(id=location_id)

    template = loader.get_template('static/probe.html')

    context = {
        'probe': probe,
        'location': location,
        }

    return HttpResponse(template.render(context,request))
    return HttpResponse("Hello, world. You're at the polls index.")

def delete_probe(request, location_id, probe_id):
    Probe.objects.filter(id = probe_id).delete()
    return redirect ('location_detail', location_id = location_id)


def probes(request):
    all_probes = Probe.objects.all()

    template = loader.get_template('static/index.html')

    context = {
        'all_probes': all_probes,
        }

    return HttpResponse(template.render(context,request))

