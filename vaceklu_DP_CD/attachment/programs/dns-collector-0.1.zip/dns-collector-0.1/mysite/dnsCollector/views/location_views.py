from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
import logging

from ..models import Probe, Location, Broadcast, Anycast, Users
from ..forms import LocationForm, ProbeForm, AnycastToLocationForm, SelectUserForm
from ..tools import render_debug, render_error


def renderLocationSite(request, form = {}):
    all_locations = Location.objects.all()
    probes_count = {}
    for i in all_locations:
        probes = len(Probe.objects.filter(id_location = i.id))
        probes_count[i.id] = probes

    template = loader.get_template('static/location.html')

    context = {
        'all_locations': all_locations,
        'probes_count': probes_count,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def location(request):
    if request.method == 'GET':
        return renderLocationSite(request)
    elif request.method == 'POST':
        location_form = LocationForm(request.POST)
        if location_form.is_valid():
            location_name = location_form.cleaned_data['name']
            location_domain_name = location_form.cleaned_data['domain_name']
            location_stack = location_form.cleaned_data['stack']
            l = Location(
                    name = location_name,
                    domain_name = location_domain_name,
                    stack = location_stack
                )
            l.save()
            loc = Location.objects.get(id = l.id)
            if loc.stack == False:
                p = Probe(
                        name = loc.name,
                        ipv4_address = '127.0.0.1',
                        ipv6_address = '::1',
                        id_location = loc,
                    )
                p.save()
        else:
            return renderLocationSite(request, form = {'form': location_form})
        return redirect('location')

def render_location_detail_site(request, location_id, form={}):
    location = Location.objects.get(id=location_id )
    location_probes = Probe.objects.filter(id_location= location_id)
    probes = len(Probe.objects.filter(id_location = location_id))
    all_anycast = Anycast.objects.all()
    assigned_anycast = Broadcast.objects.all().select_related('id_location').select_related('id_anycast').filter(id_location = location_id).order_by('id_anycast__letter')
#    return render_debug(request, assigned_anycast)

    all_users = [(o.name, o.id) for o in Users.objects.all()]
    user = None
    if location.id_user != None:
        user = Location.objects.get(id = location_id).id_user.name

    template = loader.get_template('static/location_detail.html')

    context = {
        'location': location,
        'location_probes': location_probes,
        'probes_count': probes,
        'all_anycast' : all_anycast,
        'assigned_anycast' : assigned_anycast,
        'user': user,
        'all_users' : all_users,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def location_detail(request, location_id):
    if request.method == 'GET':
        return render_location_detail_site(request, location_id)
    elif request.method == 'POST':
        probe_form = ProbeForm(request.POST)
        if probe_form.is_valid():
            probe_name = probe_form.cleaned_data['name']
            probe_ipv4 = probe_form.cleaned_data['ipv4_address']
            probe_ipv6 = probe_form.cleaned_data['ipv6_address']

            location = Location.objects.get(id=location_id )
            p = Probe(
                    name = probe_name,
                    ipv4_address = probe_ipv4,
                    ipv6_address = probe_ipv6,
                    id_location = location,
                )
            p.save()
        else:
            return render_location_detail_site(request, location_id, form = {'form': probe_form})
        return redirect('location_detail', location_id = location_id )

def delete_location(request, location_id):
    Location.objects.filter(id = location_id).delete()
    return redirect ('location')
    return renderIndexSite(request)

def location_add_anycast(request, location_id):
    global ANYCAST_CHOICES
    if request.method == 'GET':
        return redirect('location_detail', location_id = location_id )
    elif request.method == 'POST':
#        anycast_all = Anycast.objects.all()
        anycast_all = []
        ANYCAST_CHOICES =[(o.id, o.id) for o in Anycast.objects.all()]
        loc_any_form = AnycastToLocationForm(request.POST )
        if loc_any_form.is_valid():
            loc_any_add = loc_any_form.cleaned_data['anycast']
            for i in loc_any_add:
                get_broadcast = Broadcast.objects.filter(id_location = location_id, id_anycast = i)
                if len(get_broadcast) == 0:
                    l = Location.objects.get(id = location_id)
                    a = Anycast.objects.get(id = int(i))
                    b = Broadcast(id_location = l, id_anycast = a)
                    b.save()
        else:
            return render_location_detail_site(request, location_id, form = {'form': loc_any_form})
        return redirect('location_detail', location_id = location_id )

def location_remove_user(request, location_id):
    location = Location.objects.get(id = location_id)
    location.id_user = None
    location.save()
    return redirect('location_detail', location_id = location_id )

def location_select_user(request, location_id):
    select_user_form = SelectUserForm(request.POST)
    if select_user_form.is_valid():
        selected_user = select_user_form.cleaned_data['user']
        user = Users.objects.get(id = selected_user[0])
        location = Location.objects.get(id = location_id)
        location.id_user = user
        location.save()
    else:
        return renderCollectorSite(request, form = {'form' : select_user_form})
    return redirect('location_detail', location_id = location_id )


def location_delete_anycast(request, location_id, anycast_id):
    Broadcast.objects.filter(id_location = location_id, id_anycast = anycast_id).delete()
    return redirect('location_detail', location_id = location_id )

def render_modify_location(request, location_id, form = {}):
    location = Location.objects.get(id=location_id )

    template = loader.get_template('static/modify_location.html')

    context = {
        'location': location,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def modify_location(request, location_id):
    if request.method == 'GET':
        return render_modify_location(request, location_id)
    elif request.method == 'POST':
        location_form = LocationForm(request.POST)
        if location_form.is_valid():
            location_name = location_form.cleaned_data['name']
            location_domain_name = location_form.cleaned_data['domain_name']
            location_stack = location_form.cleaned_data['stack']

            l = Location.objects.get(id=location_id )
            l.name = location_name
            l.domain_name = location_domain_name
            if str(l.stack) != str(location_stack):
                l.stack = location_stack
                ## Delete all probes that have location_id as a foreign key
                Probe.objects.filter(id_location= location_id).delete()

                ## Create templat probe
                if location_stack == 'False':
                    p = Probe(
                        name = l.name,
                        ipv4_address = '127.0.0.1',
                        ipv6_address = '::1',
                        id_location = l,
                    )
                    p.save()

            l.save()
        else:
            return render_modify_location(request, location_id, form = {'form': location_form})
        return redirect('location_detail', location_id = location_id )

