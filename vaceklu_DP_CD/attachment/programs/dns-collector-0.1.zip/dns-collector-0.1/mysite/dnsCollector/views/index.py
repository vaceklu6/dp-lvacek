from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
import requests
import json
import logging

from ..models import Probe, Location, Broadcast, Anycast
from ..tools import *

def renderIndexSite(request):
    template = loader.get_template('static/index.html')
    context = {
        }
    return HttpResponse(template.render(context,request))

def index(request):
    return renderIndexSite(request)

## Parse config from probes
def parse_request_output(location, json_input):
    json_output = {}
#    json_output['name'] = location.name
    json_output['anycast'] = []
    if location.stack == True:
        try:
            json_output['probes'] = json_input['probes']
            tmp = [key for key, value in json_output['probes'].items()]
            if json_input['probes']:
                for i in tmp:
                    if 'anycast' in json_input[i].keys():
                        json_output['anycast'] = json_input[tmp[0]]['anycast']
                        break
        except:
            json_output = json_input
    else:
        json_output['probes'] = "standalone"
        json_output['anycast'] = json_input['anycast']
    return json_output

def create_probe_dict(probes):
    probe_dict = {}
    for probe in probes:
         probe_dict[probe.name] = {}
         probe_dict[probe.name] = {'ipv4' : probe.ipv4_address, 'ipv6':probe.ipv6_address}
    return probe_dict

def create_anycast_dict(assigned_anycast):
    anycast_dict = {}
    for anycast in assigned_anycast:
         anycast_dict[anycast.id_anycast.letter] = {}
         anycast_dict[anycast.id_anycast.letter] = {'ipv4' : anycast.id_anycast.ipv4_address, 'ipv6':anycast.id_anycast.ipv6_address}
    return anycast_dict

# Collect config from probes
def get_location_config(location, core_server_config):
    core_server_config[location.name] = {}
#    core_server_config[location.name]['name'] = location.name

    ## Probes
    if location.stack == True:
        location_probes = Probe.objects.filter(id_location= location.id)
#        core_server_config[location.name]['probes'] = [probe.name for probe in location_probes]
        core_server_config[location.name]['probes'] = create_probe_dict(location_probes)
    else:
        core_server_config[location.name]['probes'] = 'standalone'

    ## Anycast
    assigned_anycast = Broadcast.objects.all().select_related('id_location').select_related('id_anycast').filter(id_location = location.id).order_by('id_anycast__letter')
    core_server_config[location.name]['anycast'] = create_anycast_dict(assigned_anycast)
    return core_server_config



def renderIndexConfigSite(request):
    locations = Location.objects.all()
    monitoring_config = {}

    core_server_config = {}

    for location in locations:
        login = {}
        login['login'] = get_login_dict(location)
        result = send_request('GET', location, 'config', payload = json.dumps(login))
        json_input = process_response(result)
        monitoring_config[location.name] = parse_request_output(location, json_input)
        core_server_config = get_location_config(location, core_server_config)

    template = loader.get_template('static/index.html')
    context = {
        'monitoring_config': monitoring_config,
        'core_server_config': core_server_config
        }
    return HttpResponse(template.render(context,request))

## Send config of probes to middleware
def send_probes_config(location):
#    probes_json = {}
    probes_json = { 'probes': {}}
    probes_json['probes'] = create_probe_dict(Probe.objects.filter(id_location= location.id))
    probes_json['login'] = get_login_dict(location)
    result = send_request('POST', location, 'probes', payload = json.dumps(probes_json))


## Send config of anycasts
def send_anycast_config(request, location):
    assigned_anycast = Broadcast.objects.all().select_related('id_location').select_related('id_anycast').filter(id_location = location.id).order_by('id_anycast__letter')
    anycast_json = {}
    anycast_json['anycast'] = create_anycast_dict(assigned_anycast)
    anycast_json['login'] = get_login_dict(location)
    login = {}
    login['login'] = get_login_dict(location)

    response = send_request('DELETE', location, 'configDel', payload = json.dumps(login))

    response = send_request('POST', location, 'config', payload = json.dumps(anycast_json))

def post_config(request):
    locations = Location.objects.all()
    for location in locations:
        if location.stack == True:
            send_probes_config(location)
        send_anycast_config(request, location)

def render_debug(request, variable):
    template = loader.get_template('static/tmp.html')
    context = {'tmp': variable,}
    return HttpResponse(template.render(context,request))

def index_config(request):
    if request.method == 'GET':
        return renderIndexConfigSite(request)
    elif request.method == 'POST':
        post_config(request)
        return redirect('index_config')
#        return render_debug(request, result[1].json())
#        return HttpResponse(f'POST confiuration')
