from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
import logging

from ..models import Probe, Location, Anycast, Broadcast
from ..forms import AnycastForm

# Get an instance of a logger
logger = logging.getLogger(__name__)

def render_anycast(request, form = {}):
    all_anycast = Anycast.objects.all()

    template = loader.get_template('static/anycast.html')

    context = {
        'all_anycast': all_anycast,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def anycast(request):
    if request.method == 'GET':
        return render_anycast(request)
    elif request.method == 'POST':
        anycast_form = AnycastForm(request.POST)
        if anycast_form.is_valid():
            anycast_name   = anycast_form.cleaned_data['name']
            anycast_letter = anycast_form.cleaned_data['letter']
            anycast_ipv4   = anycast_form.cleaned_data['ipv4_address']
            anycast_ipv6   = anycast_form.cleaned_data['ipv6_address']
            anycast_notes  = anycast_form.cleaned_data['notes']

            a = Anycast(
                    name = anycast_name,
                    letter = anycast_letter,
                    ipv4_address = anycast_ipv4,
                    ipv6_address = anycast_ipv6,
                    notes = anycast_notes,
                )
            a.save()
        else:
            return render_anycast(request, form={'form': anycast_form})
        return redirect('anycast')

def anycast_detail(request, anycast_id):
    anycast = Anycast.objects.get(id = anycast_id)
    assigned_locations = Broadcast.objects.all().select_related('id_location').select_related('id_anycast').filter(id_anycast = anycast_id)
    template = loader.get_template('static/anycast_detail.html')

    context = {
        'anycast': anycast,
        'assigned_locations': assigned_locations,
        }
    return HttpResponse(template.render(context,request))
    return HttpResponse(f'Anycast detail')

def anycast_delete_location(request, location_id, anycast_id):
    Broadcast.objects.filter(id_location = location_id, id_anycast = anycast_id).delete()
    return redirect('anycast_detail', anycast_id = anycast_id )

def render_modify_anycast(request, anycast_id, form = {}):
    anycast = Anycast.objects.get(id=anycast_id)

    template = loader.get_template('static/modify_anycast.html')

    context = {
        'anycast': anycast,
        }

    if 'form' in form.keys():
        context['form'] = form['form']

    return HttpResponse(template.render(context,request))

def modify_anycast(request, anycast_id):
    if request.method == 'GET':
        return render_modify_anycast(request, anycast_id)
    elif request.method == 'POST':
        anycast_form = AnycastForm(request.POST)
        if anycast_form.is_valid():
            anycast_name  = anycast_form.cleaned_data['name']
            anycast_ipv4  = anycast_form.cleaned_data['ipv4_address']
            anycast_ipv6  = anycast_form.cleaned_data['ipv6_address']
            anycast_letter = anycast_form.cleaned_data['letter']
            anycast_notes  = anycast_form.cleaned_data['notes']

            a = Anycast.objects.get(id=anycast_id)
            a.name = anycast_name
            a.ipv4_address = anycast_ipv4
            a.ipv6_address = anycast_ipv6
            a.letter = anycast_letter
            a.notes = anycast_notes
            a.save()
        else:
            return render_modify_anycast(request, anycast_id, form={'form': anycast_form})
        return redirect('anycast_detail', anycast_id= anycast_id)

def delete_anycast(request, anycast_id):
    Anycast.objects.filter(id = anycast_id).delete()
    return redirect ('anycast')
