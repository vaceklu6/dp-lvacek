from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
import requests
import json
import logging

from ..models import Users
from ..forms import NameUserForm, UserForm, PasswordUserForm

from ..tools import verify_password, hash_password, render_debug, render_error

def render_users(request, form= {}):
    users = [(i.name, i.id) for i in Users.objects.all()]

    template = loader.get_template('static/users.html')
    context = {
        'users': users,
        }
    if 'form' in form.keys():
        context['form'] = form['form']
    return HttpResponse(template.render(context,request))

def create_user(request):
    user_form = UserForm(request.POST)
    if user_form.is_valid():
        user_name = user_form.cleaned_data['name']
        user_password = user_form.cleaned_data['password']
        user_confirm_password = user_form.cleaned_data['confirm_password']

        if user_password != user_confirm_password:
            return render_error(request, f"Password and confirm password do not match.")

        u = Users(
                name = user_name,
                password = user_password,
#                password = hash_password(user_password),
            )
        u.save()
    else:
        return render_users(request, {'form': user_form})
    return redirect('users')


def users(request):
    if request.method == 'GET':
        return render_users(request)
    elif request.method == 'POST':
        return create_user(request)

def render_password_user(request, user_id, form = {}):
    user_name = Users.objects.get(id = user_id).name

    template = loader.get_template('static/password_user.html')
    context = {
        'user_name': user_name,
        'user_id': user_id,
        }
    if 'form' in form.keys():
        context['form'] = form['form']
    return HttpResponse(template.render(context,request))


def password_user(request, user_id):
    if request.method == 'GET':
        return render_password_user(request, user_id)
    elif request.method == 'POST':
        user_form = PasswordUserForm(request.POST, extra = user_id)
        if user_form.is_valid():
            user_password = user_form.cleaned_data['password']

            user = Users.objects.get(id = user_id)

            user.password = user_password
            user.save()
        else:
            return render_password_user(request, user_id, form={ 'form': user_form})
        return redirect('users')


def render_name_user(request, user_id, form = {}):
    user_name = Users.objects.get(id = user_id).name
    user_id = Users.objects.get(id = user_id).id

    template = loader.get_template('static/name_user.html')
    context = {
        'user_name': user_name,
        'user_id': user_id,
        }
    if 'form' in form.keys():
        context['form'] = form['form']
    return HttpResponse(template.render(context,request))


def name_user(request, user_id):
    if request.method == 'GET':
        return render_name_user(request, user_id)
    elif request.method == 'POST':
        user_form = NameUserForm(request.POST)
        if user_form.is_valid():
            user_name = user_form.cleaned_data['name']

            user = Users.objects.get(id = user_id)

            user.name = user_name
            user.save()
        else:
            return render_name_user(request, user_id, form={'form': user_form})
        return redirect('users')

def delete_user(request, user_id):
    Users.objects.filter(id = user_id).delete()
    return redirect('users')
#

