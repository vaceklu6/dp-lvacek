from django.apps import AppConfig
from django.db import connection

class DNSCollectorConfig(AppConfig):
    name = 'dnsCollector'
    c = None

    ## Init function
    def ready(self):
        from .tools import CollectorAPI, init_database, init_asn_database_folder
        from .views import collector_handler
#        from .models import ItemsDB
#        ItemsDB.objects.all().delete()

        ## Test if database were created
        def db_table_exists(table_name):
            return table_name in connection.introspection.table_names()
        if db_table_exists(f'{self.name}_itemsdb'):
            self.c = CollectorAPI()
            init_database()
#            collector_handler(None)

#    def _exit(self):
#        if self.c.get_process_lock() == 1:
#            collector_handler(None)
#        init_asn_database_folder()
