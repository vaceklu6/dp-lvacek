import time
import schedule
from django.db import models
import requests
import json
from multiprocessing import Process
from threading import Thread
from elasticsearch import Elasticsearch
from elasticsearch import helpers
import os
from pathlib import Path
import pyasn
import errno
import glob
import re
from datetime import datetime

from ..tools import get_user_from_location, get_elastic_user, send_request, process_response
from ..models import Location, ItemsDB, Users

process_exit=0

class CollectorAPI():
    '''
    Class that is API of data collection from probes
    This class starts/ends thread that collect data
    '''

    def __init__(self):
        global process_exit
        process_exit = 0
        self.p = None
        self.process_lock = 0
        self.asn_database_path = "/usr/share/dns-collector"
        self.asn_database_file = ""
        self.set_asn_database_file()

    def get_process_lock(self):
        return self.process_lock

    def get_asn_database_path(self):
        return self.asn_database_path

    # Test if database of ASN exists
    def get_asn_database_status(self):
        if not os.path.exists(self.asn_database_path):
            return False, f'Folder "{self.asn_database_path}" does not exist.'

        file_path = Path(self.asn_database_path) / Path(self.asn_database_file)

        if not file_path.is_file():
            return False, f'File {file_path} does not exist or is not a file.'
        try:
            with open(file_path.absolute()) as f:
                s = f.read()
                return True, file_path.absolute()
        except IOError as x:
            if x.errno == errno.ENOENT:
                return False, f'File "{file_path.absolute()}" does not exist or is not a file.'
            elif x.errno == errno.EACCES:
                return False, f'User of running program cannot read file "{file_path.absolute()}".'
            else:
                return False, f'Unspecified error with "{file_path.absolute()}".'

        if not Path(file_path).is_file():
            return False, f'File {file_path} does not exist or is not file.'

    ## Set asn database from local storage
    def set_asn_database_file(self):
        pattern = re.compile(r'^asn_database_[0-9]{8}.dat$')
        try:
            asn_databases = [f for f in os.listdir(self.asn_database_path) if pattern.search(f)]
        except:
            return ""

        if len(asn_databases) == 0:
            self.asn_database_file = ""
            return self.asn_database_file

        if len(asn_databases) == 1:
            self.asn_database_file = asn_databases[0]
            return self.asn_database_file

        index = -1
        best_index = -1
        datemask = '%Y%m%d'
        for i in asn_databases:
            if index == -1:
               index = 0
               best_index = 0
               continue

            date_new  = datetime.strptime(i.split('_')[2].split('.')[0], datemask)
            date_best = datetime.strptime(asn_databases[best_index].split('_')[2].split('.')[0], datemask)
            if (date_new - date_best).days > 0:
                best_index = index + 1
            index += 1

        self.asn_database_file = asn_databases[best_index]
        return self.asn_database_file

    # Starts/ends collector
    def collector_handler(self):
        global process_exit
        if self.process_lock == 0:
            self.process_lock = 1
            process_exit = 0
            frequency = int(ItemsDB.objects.filter(key = 'frequency')[0].value)
            self.set_asn_database_file()
            asn_database = None
            if self.get_asn_database_status()[0] == True:
                asn_database = Path(self.asn_database_path) / Path(self.asn_database_file)
                asn_database = asn_database.absolute()
            self.p = Thread(target=run_collector, args=(frequency,asn_database))
#            self.p.deamon = True
            self.p.start()
        else:
            process_exit = 1
            self.p.join()
            self.process_lock = 0

    # Test collection and connection with elastic
    def test_collection(self):
        '''
        Test upload and download data
        '''

        responses = []
        locations = Location.objects.all()
        for location in locations:
            user_name, user_password = get_user_from_location(location)

            json_input={}
            json_input['login'] = {'name': user_name, 'password': user_password}
            response = send_request('GET', location, '', payload = json.dumps(json_input))
            responses.append(process_response(response))

        elastic_msg = ""
        user_name, user_password =  get_elastic_user()
        elastic_server = ItemsDB.objects.filter(key='elastic_server')[0]
        elastic_port = ItemsDB.objects.filter(key='elastic_port')[0]
        elastic_index = ItemsDB.objects.filter(key='elastic_index')[0]
        try:
            es = Elasticsearch(
                            [f'{elastic_server.value}'],
                            http_auth=(user_name, user_password),
                            scheme='https',
                            port=elastic_port.value,
                        )
            elastic_msg = "Connection: OK"
            if not es.ping():
                elastic_msg = "Connection: Failed"
        except:
            elastic_msg = "Exception raised"

        return responses, elastic_msg

## Collect data from one location
## Then send them to Elastic
def collector_thread(location, asn_database):
#    f = open(f"/tmp/tester_{location.name}.txt", "a")
    response = None
    user_name, user_password = get_user_from_location(location)

    json_input={}
    json_input['login'] = {'name': user_name, 'password': user_password}

    response = send_request('DELETE', location, '', payload = json.dumps(json_input))
    if response[0] == False:
        return
    ## Parse input in Elastic Format
    if response[1].status_code == 200:
        to_elastic = []

        user_name, user_password = get_elastic_user()

        elastic_server = ItemsDB.objects.filter( key = 'elastic_server')[0]
        elastic_port = ItemsDB.objects.filter( key = 'elastic_port')[0]
        elastic_index = ItemsDB.objects.filter( key = 'elastic_index')[0]
        asndb = None
        if asn_database != None:
            try:
                asndb = pyasn.pyasn(f'{asn_database}')
            except:
                pass
        try:
            es = Elasticsearch(
                            [f'{elastic_server.value}'],
                            http_auth=(user_name, user_password),
                            scheme='https',
                            port=elastic_port.value,
                        )
            if location.stack == True:
                for key, value in response[1].json().items():
                    to_elastic = parse_location(elastic_index.value, value, asndb, location.name)
                    helpers.bulk(es, to_elastic)
            else:
                to_elastic = parse_location(elastic_index.value, response[1].json(), asndb, location.name)
                helpers.bulk(es, to_elastic)
        except:
            pass

## COnvert ip to ASn
## If it fails return -1
def convert_ip_to_as_number(ip, asndb):
    if asndb == None:
        return -1
    try:
        as_number = asndb.lookup(f'{ip}')[0]
    except:
        as_number = -1
    return as_number

## Convert data from probe format to elastic format
def parse_location(es_index, json_input, asndb, location_name):
    if not isinstance(json_input, dict):
        return []

    records = []
    for key, value in json_input['traffic'].items():
        es_header={
            "_index": es_index,
            "_source": {},
            }
        record_dict = {}
        record_dict['dns'] = json_input['dns']
        record_dict['location'] = location_name
        record_dict['timestamp'] = json_input['timestamp']
        record_dict['ip_address'] = key

        json_keys = ['queries', 'RTT_sum', 'RTT_queries', 'RTT_min', 'RTT_max']
        for i in json_keys:
            if i in value:
                record_dict[i] = value[i]
        if 'anycast' in value:
            if isinstance(value['anycast'], dict):
                for anycast_key, anycast_value in value['anycast'].items():
                    record_dict[f'anycast_{anycast_key}'] = anycast_value

        if 'RTT_queries' in value and 'RTT_sum' in value:
            if value['RTT_queries'] > 0:
                record_dict['RTT_avg'] = value['RTT_sum'] / value['RTT_queries']

        record_dict['as_number'] = convert_ip_to_as_number(key, asndb)

        es_header['_source'] = record_dict.copy()
        records.append(es_header.copy())

    return records

## Run 1 thread 1 location
## After all location will have thread then delete those threads
def job(frequency, asn_database):
    from ..models import Location
    locations = Location.objects.all()

    thread_list = []
    for location in locations:
        t = Thread(target=collector_thread, args=(location, asn_database))
        thread_list.append(t)
        t.start()

    for t in thread_list:
        t.join()


## Run collection at specified frequence
def run_collector(frequency, asn_database):
    global process_exit
    schedule.every(frequency).seconds.do(lambda: job(frequency, asn_database))

    while True:
        if process_exit == 1:
            break
        schedule.run_pending()
        time.sleep(1)
