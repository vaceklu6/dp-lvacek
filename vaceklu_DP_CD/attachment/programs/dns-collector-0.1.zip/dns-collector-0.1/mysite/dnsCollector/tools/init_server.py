## Prepare database and repair it make few repairs if it gets wrong
def init_database():
    from ..models import ItemsDB

    key_names = [
            'elastic_server',
            'elastic_port',
            'elastic_index',
            'elastic_user_id',
            'frequency',
            'rtt_candidates',
            'timeout_stack',
            'timeout_standalone',
            'retry',
            ]

    for key_value in key_names:
        if ItemsDB.objects.filter(key = key_value).count() > 1:
            ItemsDB.objects.filter( key = key_value).delete()
        if ItemsDB.objects.filter(key = key_value).count() == 0:
            if key_value == 'retry':
                i = ItemsDB( key = key_value, value = '3')
                i.save()
            elif key_value == 'timeout_stack':
                i = ItemsDB( key = key_value, value = '20')
                i.save()
            elif key_value == 'timeout_standalone':
                i = ItemsDB( key = key_value, value = '5')
                i.save()
            else:
                i = ItemsDB( key = key_value, value = '')
                i.save()


def init_asn_database_folder():
    from pathlib import Path
    from django.apps import apps
#    import os
    app_config = apps.get_app_config('dnsCollector')
    asn_folder = app_config.c.get_asn_database_path()
#    if not os.path.exists(asn_folder):
#        os.mkdir(asn_folder)
#    if not asn_folder.is_dir():
#         os.mkdir(asn_folder)
    Path(asn_folder).mkdir(parents=True, exist_ok=True)
