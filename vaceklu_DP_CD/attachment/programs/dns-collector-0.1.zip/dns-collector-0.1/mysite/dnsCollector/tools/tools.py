from django.http import HttpResponse
from django.template import loader
import requests
import json
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

from ..models import Probe, Users, Location, ItemsDB

DEFAULT_TIMEOUT = 5 # seconds

## Class for timeouts and retries
class TimeoutHTTPAdapter(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        self.timeout = DEFAULT_TIMEOUT
        if "timeout" in kwargs:
            if kwargs["timeout"] != None:
                self.timeout = kwargs["timeout"]
            del kwargs["timeout"]
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)


## Test render
def render_debug(request, variable):
    template = loader.get_template('static/tmp.html')
    context = {'tmp': variable,}
    return HttpResponse(template.render(context,request))

## Error render
def render_error(request, error):
    template = loader.get_template('static/error.html')
    context = {'error': error,}
    return HttpResponse(template.render(context,request))

# Send get request
def send_get(session, url, payload):
    return session.get(url, data = payload)

# Send post request
def send_post(session, url, payload):
    return session.post(url, data = payload)

# Send delete request
def send_delete(session, url, payload):
    return session.delete(url, data = payload)

request_types = {
    'GET': send_get,
    'POST': send_post,
    'DELETE': send_delete,
}

# Send request
def send_request(request_type, location, directive, payload = json.dumps({})):
    timeout = int(ItemsDB.objects.filter( key = "timeout_stack")[0].value)
    if location.stack == False:
        timeout = int(ItemsDB.objects.filter( key = "timeout_standalone")[0].value)

    retryDB = int(ItemsDB.objects.filter( key = "retry")[0].value)
    retry_strategy = Retry(
        total=retryDB,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["DELETE", "GET"]
    )

    try:
        url = f'https://{location.domain_name}/{directive}'
        adapter = TimeoutHTTPAdapter(max_retries = retry_strategy, timeout = timeout)
        session = requests.Session()
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers = {'Content-Type': 'application/json'}
        r = request_types[request_type](session, url, payload)
    except requests.exceptions.Timeout:
        return False, f'Connection timeout'
    except requests.exceptions.SSLError:
        return False, f'HTTPS/SSL problem'
    except requests.exceptions.RequestException as e:
        return False, f'{e}'
    return (True, r)

# Parse response
def process_response(response):
    answer = ""
    if response[0] != False:
        if response[1].status_code == 200:
            answer = response[1].json()
        else:
#            answer = f'{location.name}: {response[1].status_code} - {response[1].content}'
            answer = f'{response[1].status_code} - {response[1].text}'
    else:
#        answer = f'{location.name}: {response[1]}'
        answer = f'{response[1]}'
    return answer


