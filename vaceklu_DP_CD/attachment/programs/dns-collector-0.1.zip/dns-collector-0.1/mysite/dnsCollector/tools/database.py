from ..models import ItemsDB, Users, Location

## Get user and password specified for location
def get_user_from_location(location):
    ## Get name and passwd of user
    user_name = ""
    user_password = ""
    user = Location.objects.get(id = location.id).id_user
    if user != None:
         user_name = user.name
         user_password = user.password
    return user_name, user_password

## Get user and password for elastic user
def get_elastic_user():
    user_name = ""
    user_password = ""
    elastic_user_id = ItemsDB.objects.filter(key = 'elastic_user_id')[0].value
    if elastic_user_id != "":
        user = Users.objects.get(id = int(elastic_user_id))
        user_name = user.name
        user_password = user.password
    return user_name, user_password

## Get user and password from location and return them as prepared dict
def get_login_dict(location):
    login = {}

    login['name'] = ""
    login['password'] = ""
    if location.id_user != None:
        user = Location.objects.get(id = location.id).id_user
        login['name'] = user.name
        login['password'] = user.password

    return login

