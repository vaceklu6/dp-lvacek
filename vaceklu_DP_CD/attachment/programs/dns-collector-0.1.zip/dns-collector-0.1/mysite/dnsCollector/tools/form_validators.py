from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
import ipaddress
from  ..models import Users

## Checks for forms


def bigger_equal_zero(value):
    if value < 0:
        raise ValidationError(
            _('%(value)s is not bigger or equal than 0.'),
            params={'value': value},
        )


def bigger_than_zero(value):
    if value <= 0:
        raise ValidationError(
            _('%(value)s is not bigger than 0.'),
            params={'value': value},
        )

def empty_string(value):
    if len(value.replace(" ", "")) == 0:
         raise ValidationError(
            _('is empty or contains only spaces.'),
            params={'value': value},
        )

def duplicity_users_name(value):
    names = [ u.name for u in Users.objects.all()]
    if value in names:
          raise ValidationError(
            _('%(value)s name exists'),
            params={'value': value},
        )

def valid_ipv4_address(value):
    try:
        ip_address = ipaddress.IPv4Address(value)
    except ValueError:
        raise ValidationError(
            _(f'{value} is not valid IPv4 address format.'),
            params={'value': value},
        )

def valid_ipv6_address(value):
    try:
        ip_address = ipaddress.IPv6Address(value)
    except ValueError:
        raise ValidationError(
            _(f'{value} is not valid IPv6 address format.'),
            params={'value': value},
        )

def setup_ip(cleaned_data):
    try:
        ipv4 = cleaned_data['ipv4_address']
    except:
        ipv4 = ""

    try:
        ipv6 = cleaned_data['ipv6_address']
    except:
        ipv6 = ""


    if ipv4 == "" and ipv6 == "":
        raise ValidationError("IPv4 or IPv6 have to be set up.")

