from django.db import models

# Create your models here.

class Users(models.Model):
    name = models.CharField(max_length = 50)
    password = models.CharField(max_length = 200)

class Location(models.Model):
    name = models.CharField(max_length = 40)
    stack = models.BooleanField(default = False)
    domain_name = models.CharField(max_length = 260, default = "")
    id_user = models.ForeignKey(
        Users,
        on_delete = models.SET_NULL,
        blank = True,
        null = True,
        )

#    def publish(self):
#        self.save()

class Probe(models.Model):
    id_location = models.ForeignKey(
        Location,
        on_delete = models.CASCADE
        )
    name = models.CharField(max_length = 40)

    ipv4_address = models.CharField(max_length = 16)
    ipv6_address = models.CharField(max_length = 40)

class Anycast(models.Model):
    name = models.CharField(max_length = 40, default="")
    letter = models.CharField(max_length = 3)
    ipv4_address = models.CharField(max_length = 16)
    ipv6_address = models.CharField(max_length = 40)
    notes = models.CharField(max_length = 200)

class Broadcast(models.Model):
    id_location = models.ForeignKey(
        Location,
        on_delete = models.CASCADE
        )
    id_anycast = models.ForeignKey(
        Anycast,
        on_delete = models.CASCADE
        )



class ItemsDB(models.Model):
    key = models.CharField(max_length = 255)
    value = models.CharField(max_length = 255)
