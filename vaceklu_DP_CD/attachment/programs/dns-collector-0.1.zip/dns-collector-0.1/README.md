# dns-core-server
## Postup jak nainstalovat aplikace je v diplomove praci.
