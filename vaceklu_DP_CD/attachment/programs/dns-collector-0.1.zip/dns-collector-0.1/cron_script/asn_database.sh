#!/bin/bash
asn_folder="/usr/share/dns-collector"
python_env="${asn_folder}/__venv__"

if [[ ! -d "$asn_folder" ]]; then
    mkdir -p "$asn_folder" 2>/dev/null
fi
cd "$asn_folder"

if [[ ! -d "${python_env}" ]]; then
    echo "NO venv folder ${python_env}" 1>&2
    exit 1
fi

. "${python_env}/bin/activate"

if [[ $(pip freeze | grep "pyasn" ) =~ pyasn ]]; then
    pyasn_util_download.py --latestv46 2>/dev/null
    new_asn_database=$(ls -1t rib.*.bz2 | head -n 1)
    pyasn_util_convert.py --single "$new_asn_database" asn_database_$(date +"%Y%m%d").dat 2>/dev/null
else
    echo "No python package 'pyasn' at env ${python_env}" 1>&2
    exit 1
fi
