# DNS Sniffer
## Postup jak nainstalovat aplikace je v diplomove praci.

