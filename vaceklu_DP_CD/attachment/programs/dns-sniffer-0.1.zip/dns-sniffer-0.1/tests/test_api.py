import flask
import importlib
import os
import tempfile

import pytest

def _import_app():
    import dns_sniffer
    importlib.reload(dns_sniffer)  # force reload (config could change)
    if hasattr(dns_sniffer, 'app'):
        return dns_sniffer.app
    elif hasattr(dns_sniffer, 'create_app'):
        return dns_sniffer.create_app(None)
    else:
        raise RuntimeError(
            "Can't find a Flask app. "
            "Either instantiate `dns_sniffer.app` variable "
            "or implement `dns_sniffer.create_app(dummy)` function. "
            "See https://flask.palletsprojects.com/en/1.1.x/patterns/appfactories/"
            "for additional information."
        )


def _test_app():
    app = _import_app()
    app.config['TESTING'] = True
    return app.test_client()


## If you change this, the Signature bellow must be updated!
#PING = {
#    'zen': 'Keep it logically awesome.',
#    'hook_id': 123456,
#    'hook': {
#        'type': 'Repository',
#        'id': 55866886,
#        'name': 'web',
#        'active': True,
#        'events': [
#            'issues',
#        ],
#        'config': {
#            'content_type': 'json',
#            'insecure_ssl': '0',
#            'secret': '********',
#        },
#    },
#    'repository': {
#        'id': 123456,
#        'name': 'ghia',
#        'full_name': 'cvut/ghia',
#        'private': False,
#    },
#    'sender': {
#        'login': 'user',
#    },
#}
#
#

def test_ping_pongs():
        app = _test_app()
        rv = app.get('/', json=PING, headers={
            })
        assert rv.status_code == 200
##
##
##def test_dangerous_ping_pong():
##    with env(GHIA_CONFIG=config_env_nosecret):
##        app = _test_app()
##        rv = app.post('/', json=PING, headers={'X-GitHub-Event': 'ping'})
##        assert rv.status_code == 200
##
##
##def test_bad_secret():
##    with env(GHIA_CONFIG=config_env):
##        app = _test_app()
##
