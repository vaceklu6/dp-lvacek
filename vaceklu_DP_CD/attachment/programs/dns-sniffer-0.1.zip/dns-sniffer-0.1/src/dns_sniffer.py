import logging
import netifaces
import sys
import flask

import re
import json
import os
import configparser
from threading import Thread, Event, Lock
from time import sleep, time
from scapy.all import sniff, Packet, DNS, IP, IPv6, TCP
from socket import gethostname
from datetime import datetime


# Threading lock
lock = Lock()

traffic_data = {}
anycast_counter = {}
listening_ip = []

anycast_conf = {}
ip_to_anycast = {}

interface_name = "" #'eth0'

candidates_size = 100
rtt_candidates = {}
rtt_candidates_order = []

config_file_path="/etc/dns-sniffer/dns-sniffer.conf"
startup_config="/etc/dns-sniffer/dns-sniffer_startup.conf"

def ip_not_in_traffic(s_ip):
    '''
    If IP is not in traffic dict create new record.
    '''
    if s_ip not in traffic_data.keys():
#        traffic_data[s_ip] = {'queries': 0, 'RTT_sum': 0, 'RTT_queries': 0, 'anycast': anycast_counter.copy()}
        traffic_data[s_ip] = {'queries': 0, 'anycast': anycast_counter.copy()}

def preprocess_packets(packet):
    '''
    Sniffer filter that procces every packet.
    If packet have some suitable information, counter of some key at traffic dict will be increased.
    '''
    global rtt_candidates
    global rtt_candidates_order
    global lock

    if IP in packet:
        d_ip = packet[IP].dst
        s_ip = packet[IP].src
    elif IPv6 in packet:
        d_ip = packet[IPv6].dst
        s_ip = packet[IPv6].src
    else:
        return

    if DNS in packet and s_ip not in listening_ip :
#        logging.getLogger(__name__).debug(packet.show())
#        print(packet.show())

        # Lock
        lock.acquire()

        ip_not_in_traffic(s_ip)

        if d_ip in ip_to_anycast:
            anycast_letter = ip_to_anycast[d_ip]
            traffic_data[s_ip]['anycast'][anycast_letter] += 1
        traffic_data[s_ip]['queries'] += 1

        # Unlock
        lock.release()

    ##RTT
    if TCP in packet:
        if packet[TCP].dport == 53 or packet[TCP].sport == 53:
            ## SYN => create candidate
            ip_key = '{}-{}'.format(s_ip, packet[TCP].sport)
            if packet[TCP].flags == 'S':
                rtt_candidates[ip_key] = 0
                rtt_candidates_order.append(ip_key)
                if len(rtt_candidates_order) > candidates_size:
                    ip_key_to_del = rtt_candidates_order.pop(0)
                    if ip_key_to_del in rtt_candidates.keys():
                        del rtt_candidates[ip_key_to_del]
            ## SYN, ACK => write time
            elif packet[TCP].flags == 'SA':
                ip_key = '{}-{}'.format(d_ip, packet[TCP].dport)
                if ip_key not in rtt_candidates.keys():
                    return
                rtt_candidates[ip_key] = packet.time
            ## ACK => calculate RTT, add to RTT number of IP, increase RTT_queries
            elif packet[TCP].flags == 'A':
                if ip_key not in rtt_candidates.keys():
                    return
                # When value i in that range it means that packet with
                # SA flags was not captured correctly
                if rtt_candidates[ip_key] <= 0:
                    return
                rtt = packet.time - rtt_candidates[ip_key]
                rtt_candidates_order.remove(ip_key)
                del rtt_candidates[ip_key]

                # RTT in [ms]
                rtt_ms = round(rtt * 1000)

                ## Time cannot be 0
                if rtt > 0 and rtt_ms == 0:
                    rtt_ms = 1

                # Lock
                lock.acquire()

#                ip_not_in_traffic(s_ip )
                if s_ip not in traffic_data.keys():
                    traffic_data[s_ip] = {'queries': 0, 'RTT_sum': 0, 'RTT_queries': 0, 'RTT_max': rtt_ms, 'RTT_min': rtt_ms ,'anycast': anycast_counter.copy()}
                elif 'RTT_sum' not in traffic_data[s_ip].keys():
                    traffic_data[s_ip]['RTT_sum'] = 0
                    traffic_data[s_ip]['RTT_queries'] = 0
                    traffic_data[s_ip]['RTT_min'] = rtt_ms
                    traffic_data[s_ip]['RTT_max'] = rtt_ms
                else:
                    if traffic_data[s_ip]['RTT_min'] > rtt_ms:
                        traffic_data[s_ip]['RTT_min'] = rtt_ms
                    if traffic_data[s_ip]['RTT_max'] < rtt_ms:
                        traffic_data[s_ip]['RTT_max'] = rtt_ms
                traffic_data[s_ip]['RTT_sum'] += rtt_ms
                traffic_data[s_ip]['RTT_queries'] += 1
#                if not 'RTT_min' in traffic_data[s_ip]:
#                    traffic_data[s_ip]['RTT_min'] = rtt_ms
#                else:
#                    if traffic_data[s_ip]['RTT_min'] > rtt_ms:
#                        traffic_data[s_ip]['RTT_min'] = rtt_ms
#                if not 'RTT_max' in traffic_data[s_ip]:
#                    traffic_data[s_ip]['RTT_max'] = rtt_ms
#                else:
#                    if traffic_data[s_ip]['RTT_max'] < rtt_ms:
#                        traffic_data[s_ip]['RTT_max'] = rtt_ms


                # Unlock
                lock.release()


def dns_sniffer():
    """
    Thread method that run sniffing at specified interface
    """
#    logging.getLogger(__name__).debug(interface_name)

    print("Start sniffing")
#    sniff(iface=interface_name, filter="port 53",  prn=preprocess_packets)
    sniff(iface=interface_name,  prn=preprocess_packets, store=0)


###############################################################################
# WEB

sniffer_blueprint = flask.Blueprint('sniffer', __name__)
def generate_default_answer():
    '''
    Create generate json header
    '''
    hostname = {'dns': gethostname()}
    location = {'location': gethostname()}
    now = datetime.utcnow()
    time_now = {'timestamp' : now.strftime("%Y-%m-%d %H:%M:%S")}
    return {**hostname, **location, **time_now}

def generate_config_answer():
    '''
    Answer contains setup information
    '''
    return {**generate_default_answer(), 'anycast': anycast_conf, 'rtt_stack_size': candidates_size }

def generate_data_answer():
    '''
    Answer contains sniffed data
    '''
    global traffic_data

    to_return_traffic = { 'traffic' : traffic_data.copy()}
    answer = {**generate_default_answer(), **to_return_traffic}
    return answer

def check_login_user():
    '''
    Method to check if is login enable and then check if user name and password match.
    '''
    if flask.current_app.config['login'] == 0:
        flask.current_app.logger.info("Login is 0")
        return

    content_type_header = flask.request.headers.get('Content-Type')
    if content_type_header == None:
        flask.current_app.logger.info("No Content-Type header")
        flask.abort(400, "No Content-Type header")
    if content_type_header.lower() != "application/json":
        flask.current_app.logger.info("Content-Type is not 'application/json'")
        flask.abort(400, "Content-Type is not 'application/json'")

    try:
        payload = flask.request.get_json()
    except:
        payload = None
        flask.current_app.logger.info("Cannot read payload")
        flask.abort(400, "Cannot read payload")

    if payload == None:
        flask.current_app.logger.info("Access is forbiden without login")
        flask.abort(401, "Access is forbiden without login")

    if 'login' not in payload:
        flask.current_app.logger.info("Access is forbiden without login")
        flask.abort(401, "Access is forbiden without login")

    if  payload['login']['name'] != flask.current_app.config['user_name']:
        flask.current_app.logger.info("Wrong name or password")
        flask.abort(401, "Wrong name or password")
    if payload['login']['password'] != flask.current_app.config['user_password']:
        flask.current_app.logger.info("Wrong name or password")
        flask.abort(401, "Wrong name or password")
    return

@sniffer_blueprint.route('/', methods=['GET'])
def index():
    '''
    Return sniffed data
    '''
    check_login_user()
    answer= generate_data_answer()
    return flask.Response(json.dumps(answer), headers={'Content-Type': 'application/json'})

@sniffer_blueprint.route('/', methods=['DELETE'])
def clear_index():
    '''
    Return sniffed data and delete them
    '''
    global traffic_data
    global lock
    check_login_user()

    # Lock
    lock.acquire()
    answer= generate_data_answer()
    traffic_data = {}
    # Unlock
    lock.release()

    return flask.Response(json.dumps(answer), headers={'Content-Type': 'application/json'})


@sniffer_blueprint.route('/config', methods=['GET'])
def get_anycast():
    '''
    Return setup of anycast
    '''
    check_login_user()
    return flask.Response(json.dumps(generate_config_answer()), headers={'Content-Type': 'application/json'})
#    return json.dumps(generate_config_answer())


@sniffer_blueprint.route('/config', methods=['POST'])
def add_anycast():
    '''
    Check recived json and if is everything correct then replace old anycast setup with new one.
    It delete procces packet information also.
    '''
    check_login_user()
    payload = flask.request.get_json()


    tmp_listening_ip = []
    if 'anycast' in payload:
#        flask.abort(400, f"Key 'anycast' is not in POST")
        if not isinstance(payload['anycast'], dict):
            flask.abort(400, "Key 'anycast' is not a dictionary")
        if len(payload['anycast'].keys()) == 0:
            flask.abort(400, "'anycast' dictionary is empty")

        parse_result = parse_post_config(payload['anycast'])
        if parse_result[0] == False:
            flask.abort(400, parse_result[1])

        write_startup_config(flask.current_app)

    return flask.Response(json.dumps(generate_config_answer()), headers={'Content-Type': 'application/json'})

@sniffer_blueprint.route('/configDel', methods=['DELETE'])
def remove_all_anycasts():
    '''
    Delete all configurations and procces packet information.
    '''
    check_login_user()
    global anycast_conf
    global traffic_data
    global ip_to_anycast
    global anycast_counter
    global listening_ip
    global lock
    # Lock
    lock.acquire()
    traffic_data = {}
    # Unlock
    lock.release()

#    traffic_data = {}
    ip_to_anycast = {}
    anycast_counter = {}
    anycast_conf = {}
    write_startup_config(flask.current_app)
    listening_ip = []
    return flask.Response(json.dumps(generate_config_answer()), headers={'Content-Type': 'application/json'})

@sniffer_blueprint.route('/config', methods=['DELETE'])
def remove_anycast():
    '''
    Remove anycast by its name/letter. It goes through recieved json list.
    It delete procces packet information also.
    '''
    check_login_user()
    content_type_header = flask.request.headers.get('Content-Type')
    if content_type_header.lower() != "application/json":
         flask.abort(400, "Content-Type is not 'application/json'")
    payload = flask.request.get_json()


    if 'anycast' in payload:
        if not isinstance(payload['anycast'], list):
            flask.abort(400, "Key 'anycast' is not a list of anycast")
        if len(payload['anycast']) == 0:
            flask.abort(400, "'anycast' list is empty")

        global anycast_conf
        for key in payload['anycast']:
            if key in anycast_conf.keys():
                del anycast_conf[key]

        tmp_listening_ip = []
        tmp_ip_to_anycast = {}
        tmp_anycast_counter = {}
        for key, value in anycast_conf.items():
            tmp_listening_ip.append(value['ipv4'])
            tmp_listening_ip.append(value['ipv6'])
            tmp_ip_to_anycast[value['ipv4']] = key
            tmp_ip_to_anycast[value['ipv6']] = key
            tmp_anycast_counter[key] = 0

        global traffic_data
        global ip_to_anycast
        global anycast_counter
        global lock
        # Lock
        lock.acquire()
        traffic_data = {}
        # Unlock
        lock.release()
#        traffic_data = {}
        ip_to_anycast = tmp_ip_to_anycast
        anycast_counter = tmp_anycast_counter
        listening_ip = tmp_listening_ip
        write_startup_config(flask.current_app)

    return flask.Response(json.dumps(generate_config_answer()), headers={'Content-Type': 'application/json'})

def parse_post_config(post_config):
    tmp_listening_ip = []
    tmp_ip_to_anycast = {}
    tmp_anycast_counter = {}
    for key, value in post_config.items():
#        if len(key) != 1:
#            flask.abort(400, f"Keys of 'anycast' dictionary are not size of 1.")
#        if key.isalpha() != True:
#            flask.abort(400, f"Keys of 'anycast' dictionary are not alphabetic letters.")
        if 'ipv4' not in value:
            return (False, "Values of 'anycast' do not contain 'ipv4 value'.")
        if 'ipv6' not in value:
            return (False, "Values of 'anycast' do not contain 'ipv6 value'.")
        if not isinstance(value['ipv4'], str):
            return (False, "'ipv4' value of 'anycast' is not str.")
        if not isinstance(value['ipv6'], str):
            return (False, "'ipv6' value of 'anycast' is not str.")
        tmp_listening_ip.append(value['ipv4'])
        tmp_listening_ip.append(value['ipv6'])
        key_4 = '{}4'.format(key)
        key_6 = '{}6'.format(key)
        tmp_ip_to_anycast[value['ipv4']] = key_4
        tmp_ip_to_anycast[value['ipv6']] = key_6
        tmp_anycast_counter[key_4] = 0
        tmp_anycast_counter[key_6] = 0

    global traffic_data
    global anycast_conf
    global ip_to_anycast
    global anycast_counter
    global lock

    # Lock
    lock.acquire()
    traffic_data = {}
    # Unlock
    lock.release()

#    traffic_data = {}
    anycast_conf = post_config
    ip_to_anycast = tmp_ip_to_anycast

    anycast_counter = tmp_anycast_counter
    for ip in tmp_listening_ip:
        if ip not in listening_ip:
            listening_ip.append(ip)

    return (True, "")

def read_startup_config(app):
    ## Test if file exists
    try:
        f = open(startup_config)
    except:
        app.logger.info('Startup config not accesible at "{}". Startup config is not readed.'.format(startup_config))
        return
    ## Read it
    ## Test if readed config is json
    config = ""
    try:
        with open(startup_config, 'r') as f:
            config = json.load(f)
    except:
        app.logger.info('Startup config is not in json format.')
        return
    parse_result = parse_post_config(config)
    if parse_result[0] == False:
        app.logger.info("Startup config NOT loaded: {}".format(parse_result[1]))
        return
    app.logger.info('Startup config loaded.')

def write_startup_config(app):
    ## Test if file exists if not create it
    ## Write it
    try:
        with open(startup_config, 'w+') as f:
            json.dump(anycast_conf, f)
    except:
        app.logger.info('Startup config cannot be written to "{}".'.format(startup_config))

def load_config_web(app):
    '''
    Loading application settup from config file.
    Try to read file and its values. If some important information is missing dns-sniffer will not start.
    '''
    global interface_name
    global candidates_size
    try:
        f = open(config_file_path)
        config = configparser.ConfigParser()
        config.optionxform = str
        with open(config_file_path) as f:
            config.read_file(f)

        if not config.has_option('settings', 'interface'):
            app.logger.critical('There is no section "settings" with option "interface"')
            exit(1)

        interface_name = config.get('settings', 'interface')
        if interface_name not in netifaces.interfaces():
            app.logger.critical('Program cannot sniff at interface "{}". Interface does not exist.'.format(interface_name))
            exit(2)

        candidates_size = 100
        if config.has_option('settings', 'rtt_candidates_size'):
            candidates_size = int(config.get('settings', 'rtt_candidates_size'))
        app.logger.info('"rtt_candidate_size" is setup to {}.'.format(candidates_size))

        app.config['login'] = 0
        if config.has_option('user', 'name') and config.has_option('user', 'password'):
            app.config['login'] = 1

        if config.has_option('user', 'name'):
            app.config['user_name'] = config.get('user', 'name')

        if config.has_option('user', 'password'):
            app.config['user_password'] = config.get('user', 'password')

    except:
        app.logger.critical('Program cannot sniff at interface. File not accesible at "{}". Program exit.'.format(config_file_path))
        candidates_size = 100
        app.config['login'] = 0
        app.config['name'] = ""
        app.config['password'] = ""


    read_startup_config(app)

def create_app(*args, **kwargs):
    '''
    Create flask app and run method to load config file.
    After reading config is runned sniffing thread.
    '''
    app = flask.Flask(__name__)

    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)

    load_config_web(app)

    thread = Thread(target = dns_sniffer )
    thread.deamon = True
    thread.start()

    app.register_blueprint(sniffer_blueprint)
    return app

###############################################################################



app = None
#logging.basicConfig(filename='/var/log/dns_sniffer.log',level=logging.DEBUG)

if __name__ == '__main__':
    app = create_app()
    app.run()


