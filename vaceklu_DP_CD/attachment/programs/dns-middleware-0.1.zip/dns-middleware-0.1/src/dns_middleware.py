import flask
import logging
import requests
import json
import os
import configparser
from  socket import gethostname
from datetime import datetime
from tools import *

###############################################################################
# WEB
dns_servers = {}
probes = {}
config_file_path="/etc/dns-middleware/dns-middleware.conf"
startup_config="/etc/dns-middleware/dns-middleware_startup.conf"


def parse_post_config(post_config, payload_key):
    for key, value in post_config.items():
        if 'ipv4' not in value:
            return (False, 'Values of "{}" do not contain "ipv4 value".'.format(payload_key))
        if 'ipv6' not in value:
            return (False, 'Values of "{}" do not contain "ipv6 value".'.format(payload_key))
        if not isinstance(value['ipv4'], str):
            return (False, '"ipv4" value of "{}" is not str.'.format(payload_key))
        if not isinstance(value['ipv6'], str):
            return (False, '"ipv6" value of "{}" is not str.'.format(payload_key))

    global probes
    probes = post_config

    return (True, "")

def read_startup_config(app):
    ## Test if file exists
    try:
        f = open(startup_config)
    except:
        app.logger.info('Startup config not accesible at "{}". Startup config is not readed.'.format(startup_config))
        return
    ## Read it
    ## Test if readed config is json
    config = ""
    try:
        with open(startup_config, 'r') as f:
            config = json.load(f)
    except:
        app.logger.info('Startup config is not in json format.')
        return
    parse_result = parse_post_config(config, 'probes')
    if parse_result[0] == False:
        app.logger.info("Startup config NOT loaded: {}".format(parse_result[1]))
        return
    app.logger.info('Startup config loaded.')

def write_startup_config(app):
    ## Test if file exists if not create it
    ## Write it
    try:
        with open(startup_config, 'w+') as f:
            json.dump(probes, f)
    except:
        app.logger.info('Startup config cannot be written to "{}".'.format(startup_config))


def load_config_web(app):
    '''
    Loading application settup from config file.
    Try to read file and its values. If some important information is missing dns-middleware will not start.
    '''
    app.config['retry'] = 3
    timeout_conf = DEFAULT_TIMEOUT
    try:
        f = open(config_file_path)
        config = configparser.ConfigParser()
        config.optionxform = str
        with open(config_file_path) as f:
            config.read_file(f)

        app.config['https'] = 0
#        if config.has_option('settings', 'https'):
#            app.config['https'] = config.get('settings', 'https')

        app.config['login'] = 0
        if config.has_option('user', 'name') and config.has_option('user', 'password'):
            app.config['login'] = 1

        if config.has_option('user', 'name'):
            app.config['user_name'] = config.get('user', 'name')

        if config.has_option('user', 'password'):
            app.config['user_password'] = config.get('user', 'password')

        app.config['timeout'] = None
        if config.has_option('settings', 'timeout'):
            tmp_timeout = int(config.get('settings', 'timeout'))
            if tmp_timeout > 0:
                app.config['timeout'] = tmp_timeout
                timeout_conf = app.config['timeout']
            else:
                app.logger.info('Request "timout" is not bigger than 0.')

        if config.has_option('settings', 'retry'):
            retry = int(config.get('settings', 'retry'))
            if retry >= 0:
                app.config['retry'] = retry
            else:
                app.logger.info('Request "retry" is not equal or bigger than 0.')
    except:
            app.logger.critical('Program cannot read file at"{}". Program will load default values'.format(config_file_path))
            app.config['timeout'] = None
            app.config['https'] = 0
            app.config['login'] = 0
            app.config['name'] = ""
            app.config['password'] = ""

#    app.logger.info('"https" is setup to {}.'.format(app.config['https']))
    app.logger.info('Request "timeout" is setup to {}.'.format(timeout_conf))
    app.logger.info('Request "retry" is setup to {}.'.format(app.config['retry']))
    app.logger.info('Login is setup to {}.'.format(app.config['login']))

    read_startup_config(app)

def check_login_user():
    '''
    Method to check if is login enable and then check if user name and password match.
    '''
    if flask.current_app.config['login'] == 0:
#        flask.current_app.logger.info("Login is 0")
        return

    content_type_header = flask.request.headers.get('Content-Type')
    if content_type_header == None:
        flask.current_app.logger.info("No Content-Type header")
        flask.abort(400, "No Content-Type header")
    if content_type_header.lower() != "application/json":
        flask.current_app.logger.info("Content-Type is not 'application/json'")
        flask.abort(400, "Content-Type is not 'application/json'")

    payload = flask.request.get_json()

    if payload == None:
        flask.current_app.logger.info("Access is forbiden without login")
        flask.abort(401, "Access is forbiden without login")

    if 'login' not in payload:
        flask.current_app.logger.info("Access is forbiden without login")
        flask.abort(401, "Access is forbiden without login")

    if  payload['login']['name'] != flask.current_app.config['user_name']:
        flask.current_app.logger.info("Wrong name or password")
        flask.abort(401, "Wrong name or password")
    if payload['login']['password'] != flask.current_app.config['user_password']:
        flask.current_app.logger.info("Wrong name or password")
        flask.abort(401, "Wrong name or password")
    return

middleware_blueprint = flask.Blueprint('middleware', __name__)

@middleware_blueprint.route('/', methods=['GET'])
def index():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    to_return = {}
    payload = flask.request.get_json()
    for key, value in probes.items():
        response = send_request_IP46('GET', value, '', https, retry, timeout, payload)
        to_return[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(to_return), headers={'Content-Type': 'application/json'})

@middleware_blueprint.route('/', methods=['DELETE'])
def index_delete():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    to_return = {}
    payload = flask.request.get_json()
    for key, value in probes.items():
        response = send_request_IP46('DELETE', value, '', https, retry, timeout, payload)
        to_return[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(to_return), headers={'Content-Type': 'application/json'})


@middleware_blueprint.route('/probes', methods=['GET'])
def get_probes():
    '''
    Return how probes are setup with theirs IP addresses.
    '''
    check_login_user()
    return flask.Response(json.dumps(probes), headers={'Content-Type': 'application/json'})

@middleware_blueprint.route('/deleteProbes', methods=['DELETE'])
def remove_all_probes():
    '''
    Remove all setup probes.
    '''
    check_login_user()
    for key in list(probes.keys()):
        del probes[key]
    return flask.Response(json.dumps(probes), headers={'Content-Type': 'application/json'})

@middleware_blueprint.route('/probes', methods=['POST'])
def add_probes():
    '''
    Check recived json and if is everything correct then replace old probes setup with new one.
    '''
    check_login_user()
    payload = flask.request.get_json()

    payload_key = 'probes'
    if payload_key in payload:
        if not isinstance(payload[payload_key], dict):
            flask.abort(400, 'Key "{}" is not a dictionary'.format(payload_key))
        if len(payload[payload_key].keys()) == 0:
            flask.abort(400, '"{}" dictionary is empty'.format(payload_key))

        parse_result = parse_post_config(payload[payload_key], payload_key)
        if parse_result[0] == False:
            flask.abort(400, parse_result[1])

        write_startup_config(flask.current_app)


#        for key, value in payload[payload_key].items():
#            if 'ipv4' not in value:
#                flask.abort(400, 'Values of "{}" do not contain "ipv4 value".'.format(payload_key))
#            if 'ipv6' not in value:
#                flask.abort(400, 'Values of "{}" do not contain "ipv6 value".'.format(payload_key))
#            if not isinstance(value['ipv4'], str):
#                flask.abort(400, '"ipv4" value of "{}" is not str.'.format(payload_key))
#            if not isinstance(value['ipv6'], str):
#                flask.abort(400, '"ipv6" value of "{}" is not str.'.format(payload_key))
#
#        global probes
#        probes = payload[payload_key]

    return flask.Response(json.dumps(probes), headers={'Content-Type': 'application/json'})

@middleware_blueprint.route('/config', methods=['GET'])
def get_config():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    stack_config = {'probes' : probes }
    payload = flask.request.get_json()
    for key, value in probes.items():
        response = send_request_IP46('GET', value, 'config', https, retry, timeout, payload)
        stack_config[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(stack_config), headers={'Content-Type': 'application/json'})


@middleware_blueprint.route('/config', methods=['POST'])
def post_config():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    stack_config = {'probes' : probes }
    payload = flask.request.get_json()
    if 'anycast' in payload:
        for key, value in probes.items():
            response = send_request_IP46('POST', value, 'config', https, retry, timeout, payload)
            stack_config[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(stack_config), headers={'Content-Type': 'application/json'})

@middleware_blueprint.route('/configDel', methods=['DELETE'])
def delete_config_config():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    stack_config = {'probes' : probes }
    payload = flask.request.get_json()
    if 'anycast' in payload:
        for key, value in probes.items():
            response = send_request_IP46('DELETE', value, 'configDel', https, retry, timeout, payload)
            stack_config[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(stack_config), headers={'Content-Type': 'application/json'})


@middleware_blueprint.route('/config', methods=['DELETE'])
def delete_config():
    '''
    Redirect request to all probes that are setup at dns-middleware.
    Return 500 when is no probe setup.
    '''
    check_login_user()
    if len(probes.keys()) <= 0:
        flask.abort(500, 'No DNS probes to get')

    https = flask.current_app.config['https']
    timeout = flask.current_app.config['timeout']
    retry = flask.current_app.config['retry']

    ## Unit timestamp
    now = datetime.utcnow()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

    stack_config = {'probes' : probes }
    payload = flask.request.get_json()
    if 'anycast' in payload:
        for key, value in probes.items():
            response = send_request_IP46('DELETE', value, 'config', https, retry, timeout, payload)
            stack_config[key] = process_response(response, timestamp)

    return flask.Response(json.dumps(stack_config), headers={'Content-Type': 'application/json'})

def create_app(*args, **kwargs):
    '''
    Create flask app and run method to load config file.
    '''
    app = flask.Flask(__name__)

    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)

    load_config_web(app)

    app.register_blueprint(middleware_blueprint)
    return app

###############################################################################

if __name__ == '__main__':
    app = create_app()
