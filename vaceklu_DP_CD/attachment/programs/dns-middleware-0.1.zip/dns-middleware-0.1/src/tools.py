import requests
import json
from  socket import gethostname
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

DEFAULT_TIMEOUT = 5 # seconds

class TimeoutHTTPAdapter(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        self.timeout = DEFAULT_TIMEOUT
        if "timeout" in kwargs:
            if kwargs["timeout"] != None:
                self.timeout = kwargs["timeout"]
            del kwargs["timeout"]
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)

def send_get(session, url, payload):
    return session.get(url, json = payload)

def send_post(session, url, payload):
    return session.post(url, json = payload)

def send_delete(session, url, payload):
    return session.delete(url, json = payload)

## Dictionary that returns propriate method
request_types = {
    'GET': send_get,
    'POST': send_post,
    'DELETE': send_delete,
}

def send_request(request_type, url, retry, timeout, payload = json.dumps({})):
    '''
    Send request with specified method by 'reqeuest_type' variable.
    Return tuple where:
        - first parameter is if request went succesfully or not
        - second parameter is error message or response answer
    '''
    retry_strategy = Retry(
        total=retry,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["DELETE", "GET"]
    )
    adapter = TimeoutHTTPAdapter(max_retries = retry_strategy, timeout = timeout)
    try:
        session = requests.Session()
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers = {'Content-Type': 'application/json'}
        r = request_types[request_type](session, url, payload)
    except requests.exceptions.Timeout:
        return False, 'Connection timeout'
    except requests.exceptions.SSLError:
        return False, 'HTTPS/SSL problem'
    except requests.exceptions.RequestException as e:
        return False, e
    return (True, r)

def process_response(response, timestamp):
    '''
    Process respons. Check if it goes well and return propriate answer.
    '''
    answer = ""
    if response[0] != False:
        if response[1].status_code == 200:
            answer = response[1].json()
            if 'location' in answer:
                answer['location'] = gethostname()
                answer['timestamp'] = timestamp
        else:
            answer = '{}:{}'.format(response[1].status_code, response[1].text)
    else:
#        answer = "Exception raised"
        answer = 'Exception raised : {}'.format(response[1])
    return answer

def get_url(ip , directive, https, ipv6 = 0):
    '''
    Create url of requested target
    '''
    if ip == "":
        return ""

    scheme = 'http'
    if https == 1:
        scheme = 'https'
    if ipv6 == 1:
        ip = '[{}]'.format(ip)
    if directive == "":
        return '{}://{}'.format(scheme, ip)
    return '{}://{}/{}'.format(scheme, ip, directive)
 #   return f'{scheme}://{ip}/{directive}'


def send_request_IP46(request_type, probe, directive, https, retry, timeout = None, payload = json.dumps({})):
    '''
    Send IPv4 request and if it fails try request via IPv6
    '''
    ## IPv4 request
    url = get_url(probe['ipv4'], directive, https)
    result = (False, "")
    if url != "":
        result = send_request(request_type, url, retry, timeout, payload)
    if result[0] == True:
        return result

    ## IPv6 request
    url = get_url(probe['ipv6'], directive, https, ipv6 = 1)
    if url != "":
        result = send_request(request_type, url, retry, timeout, payload)
    return result

##########################################################################################

